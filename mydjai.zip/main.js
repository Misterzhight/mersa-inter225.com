function save(){
  let name = document.getElementById("name").value
  let tel = document.getElementById("tel").value
  let pass = document.getElementById("pass").value
  
  localStorage.setItem("Name", name)
  localStorage.setItem("Tel", tel)
  localStorage.setItem("Password", pass)
  window.location = "verification.html"
}
let dataName = localStorage.getItem("Name")

let dataPass = localStorage.getItem("Password")
if(dataName&&dataPass){
  window.location = "verification.html"
}