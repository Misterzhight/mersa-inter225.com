let random = Math.floor(Math.random() *2)
function play(){
  
  let userVal = parseInt(document.getElementById("userVal").value)
  
  if(userVal<0||userVal>90){
    alert("number should be between 0 and 90")
  }else{
    
  
  if(userVal==random){
    alert("You won 3000.00 FCFA!!!, The win number is"+" "+random)
    let results = localStorage.getItem("Balance")
    let newBalance = results+++900;
    localStorage.setItem("Balance", newBalance)
    window.location = "view.html"
  
  }else{
    alert("You lost 100.00FCFA, the win number is"+" "+random)
    let results = localStorage.getItem("Balance")
    let newBalance = results-100;
    localStorage.setItem("Balance", newBalance)
    window.location ="view.html";
  }
}
}
let newBalance = localStorage.getItem("Balance")

if (newBalance<=0) {
      alert("Please recharge your account!")
      balances=0;
      localStorage.setItem("Balance",balances)
      window.location="rechargeMe.html"
    }
    
  